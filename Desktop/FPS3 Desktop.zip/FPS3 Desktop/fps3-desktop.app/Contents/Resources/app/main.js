const { app, BrowserWindow, BrowserView } = require("electron");
const Sender = require("electron-sender");

let views, view;

function TruBar(window = new Electron.BrowserWindow(), options = { seam: true, seamColor: "#eee", height: 20, trafficLightX: 6.5, trafficLightY: 6.5, textColor: "#fff", backgroundColor: "#343434", title: "Electron TruBar", buttons: ["x", "-", "+", "&circlearrowleft;"] }, parentWindow, view = null) {
  Sender.append(window);
  let mainWindow = window;
  parentWindow.setTrafficLightPosition({ x: (options.trafficLightX), y: (options.trafficLightY) });
  function renderProcessExecutions(process_window, handler, callback) {
    process_window.webContents.on("console-message", function(r, e, i) {
      if (i.split("[")[0] == ("#Electron:" + handler.trim() + " ")) {
        callback(i.split("[")[1].split("").reverse().splice(1).reverse().join(""));
      }
    });
  }
  Sender.receive(parentWindow, "window_close", () => {
    parentWindow.close();
  });
  Sender.receive(parentWindow, "window_minimize", () => {
    parentWindow.unmaximize();
  });
  Sender.receive(parentWindow, "window_maximize", () => {
    parentWindow.maximize();
  });
  Sender.receive(parentWindow, "window_refresh", () => {
    view && view.webContents.reload();
  });
  parentWindow.on("enter-full-screen", () => {
    mainWindow.webContents.executeJavaScript(`document.querySelector('.titlebar').style.display = 'none';`);
  });
  parentWindow.on("leave-full-screen", () => {
    mainWindow.webContents.executeJavaScript(`document.querySelector('.titlebar').style.display = 'block';`);
  });
  options.buttons = (options.buttons || ["x", "-", "+", "&circlearrowleft;"]);
  options.buttons.forEach(x => options.buttons[options.buttons.indexOf(x)] = `<span style="border:2px solid currentColor;font-weight:600!important;padding:3px;width:10px;height:10px;display:inline-flex;text-align:center;align-items:center;justify-content:center" onclick="${options.buttons.indexOf(x) == 0 ? "Sender.send('window_close')" : (options.buttons.indexOf(x) == 1 ? "Sender.send('window_minimize')" : (options.buttons.indexOf(x) == 2 ? "Sender.send('window_maximize')" : "Sender.send('window_refresh')"))}">${x}</span>`);
  mainWindow.webContents.executeJavaScript(`document.body.innerHTML = \`
  <style>*{user-select:none!important}.fake_titlebar,.fake_titlebar *{font-family:Arial!important;cursor:default!important}</style>
  <div class="titlebar" style="display:inline-flex;-webkit-app-region:drag;z-index:99999999999;background:${options.backgroundColor};position:fixed;width:100%;height:${options.height}px;padding:5px;${options.seam ? `border-bottom:2px solid ${options.seamColor};` : ``}left:0;right:0;top:0;text-align:center;justify-content:center;align-items:center;font-size:12px;color:${options.textColor};font-family:'default',Arial!important">${options.title || mainWindow.webContents.getURL()}</div>
  <div class="fake_titlebar" style="display:inline-flex;-webkit-app-region:drag;z-index:99999999999;background:transparent;position:fixed;width:100px;height:${options.height}px;padding:5px;left:0;right:0;top:0;text-align:center;justify-content:center;align-items:center;font-size:12px;color:${options.textColor};font-family:'default',Arial!important">${options.buttons.join("&ThickSpace;&ThickSpace;").replace("x", "x").replace("-", "&minus;").replace("+", "&plus;")}</div>
  \` + document.body.innerHTML;`);
  mainWindow.webContents.on("did-finish-load", () => { parentWindow.setTitle("") });
  mainWindow.webContents.on("did-start-loading", () => {
    mainWindow.webContents.executeJavaScript(`document.body.innerHTML = \`
    <style>*{user-select:none!important}.fake_titlebar,.fake_titlebar *{font-family:Arial!important;cursor:default!important}</style>
    <div class="titlebar" style="display:inline-flex;-webkit-app-region:drag;z-index:99999999999;background:${options.backgroundColor};position:fixed;width:100%;height:${options.height}px;padding:5px;${options.seam ? `border-bottom:2px solid ${options.seamColor};` : ``}left:0;right:0;top:0;text-align:center;justify-content:center;align-items:center;font-size:12px;color:${options.textColor};font-family:'default',Arial!important">${options.title || mainWindow.webContents.getURL()}</div>
    <div class="fake_titlebar" style="display:inline-flex;-webkit-app-region:drag;z-index:99999999999;background:transparent;position:fixed;width:100px;height:${options.height}px;padding:5px;left:0;right:0;top:0;text-align:center;justify-content:center;align-items:center;font-size:12px;color:${options.textColor};font-family:'default',Arial!important">${options.buttons.join("&ThickSpace;&ThickSpace;").replace("x", "&times;").replace("-", "&minus;").replace("+", "&plus;")}</div>
    \` + document.body.innerHTML;`);
  });
}

app.on("ready", () => {
  // Back-end setup
  const mainWindow = new BrowserWindow({
    paintWhenInitiallyHidden: true,
    show: false,
    center: true,
    hasShadow: true,
    frame: false,
    roundedCorners: false,
    titleBarStyle: "customButtonsOnHover"
  });
  TruBar(mainWindow, {
    backgroundColor: "#fff",
    textColor: "#333",
    seam: true,
    seamColor: "#333",
    height: 20,
    trafficLightX: 6.5,
    trafficLightY: 6.5,
    title: "FPS Desktop 2.0"
  }, mainWindow);
  mainWindow.show();

  // Front-end setup
  mainWindow.loadFile("./index.html");

  Sender.receive(mainWindow, "single", () => {
    let fakeWindow = new BrowserWindow({
      show: false
    });
    fakeWindow.loadURL("https://fps3.ml");
    fakeWindow.webContents.on("did-finish-load", () => {
      fakeWindow.webContents.executeJavaScript(`
      document.querySelector(".mini-button").click();
      `);
      mainWindow.webContents.executeJavaScript(`
      swal({
        title: "Searching for players...",
        text: "Please wait for the match to start"
      });
      `);
    });
  });
  Sender.receive(mainWindow, "split", (lobby, map, mode) => {
    let view = new BrowserView();
    let view1 = new BrowserView();
    views = [];
    views.push(view, view1);
    views[0].webContents.loadURL(`https://fps3.ml/src.html?lobby=${lobby}&map=${map}&mode=${mode}&gp=1`);
    views[1].webContents.loadURL(`https://fps3.ml/src.html?lobby=${lobby}&map=${map}&mode=${mode}&gp=2`);
    mainWindow.addBrowserView(views[0]);
    mainWindow.addBrowserView(views[1]);
    mainWindow.setSimpleFullScreen(true);
    views[0].setBounds({ x: 0, y: 0, width: mainWindow.getSize()[0], height: mainWindow.getSize()[1] / 2 });
    views[1].setBounds({ x: 0, y: mainWindow.getSize()[1] / 2, width: mainWindow.getSize()[0], height: mainWindow.getSize()[1] / 2 });
  });
  Sender.receive(mainWindow, "free", (map, mode) => {
    let view = new BrowserView();
    view.webContents.loadURL(`https://fps3.ml/src.html?freeplay=true&map=${map}&mode=${mode}`);
    mainWindow.addBrowserView(view);
    mainWindow.setSimpleFullScreen(true);
    view.setBounds({ x: 0, y: 0, width: mainWindow.getSize()[0], height: mainWindow.getSize()[1] });
  });
});